let alarmSound = null;
let alarmTimeout;
let snoozeTimeout;
let adTimer;

// Request notification permission
function requestNotificationPermission() {
    if ("Notification" in window && Notification.permission !== "granted") {
        Notification.requestPermission();
    }
}

// Show notifications
function showNotification(title, message) {
    if (Notification.permission === "granted") {
        new Notification(title, { body: message, icon: "alarm.png" });
    }
}

// Initialize AdMob
function initializeAds() {
    if (window.admob) {
        admob.banner.config({ id: 'ca-app-pub-9044426438638074/1698587875', isTesting: false });
        admob.banner.prepare();
        admob.banner.show();

        admob.interstitial.config({ id: 'ca-app-pub-9044426438638074/4990702298', isTesting: false });
        admob.interstitial.prepare();

        admob.rewardvideo.config({ id: 'ca-app-pub-9044426438638074/4293827598', isTesting: false });
        admob.rewardvideo.prepare();
    }
}

// Show all ads
function showAllAds() {
    if (window.admob) {
        if (admob.interstitial) {
            admob.interstitial.show();
            admob.interstitial.prepare();
        }
        if (admob.rewardvideo) {
            admob.rewardvideo.show();
            admob.rewardvideo.prepare();
        }
    }
}

// Start ad timer
function startAdTimer() {
    adTimer = setInterval(() => {
        showAllAds();
    }, 2 * 60 * 1000); // Show ads every 2 minutes
}

// Add new task
function addTask() {
    const taskInput = document.getElementById("taskInput").value;
    const taskTime = document.getElementById("taskTime").value;
    const days = Array.from(document.querySelectorAll('input[name="days"]:checked')).map(day => day.value);

    if (taskInput && taskTime && days.length > 0) {
        const taskList = document.getElementById("taskList");
        const listItem = document.createElement("li");

        listItem.innerHTML = `
            <span><strong>${taskInput}</strong> - <span class="time">${taskTime}</span></span>
            <button onclick="deleteTask(this)">❌</button>
        `;

        taskList.appendChild(listItem);
        checkAlarm(taskInput, taskTime, days);
    }
}

// Delete task manually
function deleteTask(btn) {
    btn.parentElement.remove();
}

// Upload custom sound
function uploadSound(event) {
    const file = event.target.files[0];
    if (file) {
        alarmSound = new Audio(URL.createObjectURL(file));
    }
}

// Check for alarm
function checkAlarm(task, time, days) {
    const now = new Date();
    const [hours, minutes] = time.split(":");
    const alarmTime = new Date();
    alarmTime.setHours(hours, minutes, 0, 0);

    if (days.includes(now.toLocaleString("en-us", { weekday: "long" }))) {
        const timeDiff = alarmTime.getTime() - now.getTime();
        if (timeDiff > 0) {
            setTimeout(() => triggerAlarm(task), timeDiff);
        }
    }
}

// Trigger alarm
function triggerAlarm(task) {
    const alarmBox = document.getElementById("alarmBox");
    alarmBox.style.display = "block";
    document.getElementById("alarmText").innerText = `Time for: ${task}`;
    if (alarmSound) alarmSound.play();

    showNotification("Alarm!", `It's time for: ${task}`);
    alarmTimeout = setTimeout(() => snoozeAlarm(task), 90 * 1000); // Auto-snooze after 1.5 mins
    showAllAds();
}

// Snooze alarm
function snoozeAlarm(task) {
    clearTimeout(alarmTimeout);
    const alarmBox = document.getElementById("alarmBox");
    alarmBox.style.display = "none";
    if (alarmSound) alarmSound.pause();

    showNotification("Alarm Snoozed", `The task "${task}" will ring again in 10 minutes`);
    snoozeTimeout = setTimeout(() => triggerAlarm(task), 10 * 60 * 1000);
}

// Dismiss alarm
function dismissAlarm() {
    clearTimeout(alarmTimeout);
    clearTimeout(snoozeTimeout);
    const alarmBox = document.getElementById("alarmBox");
    alarmBox.style.display = "none";
    if (alarmSound) alarmSound.pause();

    showNotification("Alarm Dismissed", "The alarm has been dismissed");
    showAllAds();
}

// Initialize the app
window.onload = () => {
    requestNotificationPermission();
    initializeAds();
    startAdTimer();
};
